# 🌴 Fortaleza Divertida

Descubra o que fazer hoje em Fortaleza com recomendações personalizadas geradas por IA. O app pergunta seu humor, como você quer se sentir e que tipo de programa te agrada — e sugere os 4 melhores lugares reais da cidade.

## Como funciona

```
Usuário → Site (HTML) → Servidor (Vercel Function) → API da Anthropic → Resultado
```

A chave da API fica **somente no servidor**, nunca exposta no frontend.

---

## Estrutura do projeto

```
fortaleza-divertida/
├── public/
│   └── index.html       # Frontend completo (HTML + CSS + JS)
├── api/
│   └── recomendar.js    # Serverless function (backend)
├── vercel.json          # Configuração da Vercel
├── package.json
├── .env.example         # Modelo das variáveis de ambiente
└── .gitignore
```

---

## Deploy na Vercel (passo a passo)

### 1. Faça fork ou clone do repositório

```bash
git clone https://github.com/SEU_USUARIO/fortaleza-divertida.git
cd fortaleza-divertida
```

### 2. Crie uma conta na Vercel

Acesse [vercel.com](https://vercel.com) e conecte com sua conta do GitHub.

### 3. Importe o projeto

- No dashboard da Vercel, clique em **"Add New Project"**
- Selecione o repositório `fortaleza-divertida`
- Clique em **"Deploy"** (as configurações já estão no `vercel.json`)

### 4. Configure a variável de ambiente

Após o deploy inicial (vai falhar sem a chave), vá em:

**Settings → Environment Variables** e adicione:

| Nome | Valor |
|------|-------|
| `ANTHROPIC_API_KEY` | `sk-ant-SUA_CHAVE_AQUI` |

> Obtenha sua chave em [console.anthropic.com](https://console.anthropic.com)

### 5. Redeploy

Após salvar a variável, clique em **"Redeploy"** no último deploy. Pronto! 🎉

---

## Desenvolvimento local

```bash
# Instale as dependências
npm install

# Copie o arquivo de exemplo e preencha sua chave
cp .env.example .env.local

# Rode localmente com a CLI da Vercel
npx vercel dev
```

O site ficará disponível em `http://localhost:3000`.

---

## Segurança

- ✅ Chave da API nunca exposta no frontend
- ✅ CORS configurável via variável `ALLOWED_ORIGIN`
- ✅ Validação de entrada no backend
- ✅ `.env.local` ignorado pelo Git

### Recomendações adicionais para produção

- Configure `ALLOWED_ORIGIN` com o domínio exato do seu site
- Adicione rate limiting (ex: [Upstash](https://upstash.com)) para evitar abuso de custos
- Monitore o uso da API em [console.anthropic.com](https://console.anthropic.com)

---

## Tecnologias

- **Frontend**: HTML, CSS, JavaScript puro
- **Backend**: Vercel Serverless Functions (Node.js)
- **IA**: Claude (Anthropic) com Web Search

---

Feito com ❤️ em Fortaleza
